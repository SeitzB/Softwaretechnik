/**
 * Class to Parse otherwhise non-drawable Geometrys into drawable Paths
 */

/**
 * TODO!
 */
public class GeometryParser {

}
