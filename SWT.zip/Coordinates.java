
public class Coordinates {

}
