
public class Coordinate {
	private float x;
	private float y;

	Coordinate(float x, float y) {
		this.x = x;
		this.y = y;
	}

	public float giveX() {
		return x;
	}

	public float giveY() {
		return y;
	}
}
