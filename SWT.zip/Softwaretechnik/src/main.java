public class main
{

	public static void main(String[] args)
	{
		Plotter plotter = new Plotter();
		SVGPathExtractor extractor = new SVGPathExtractor();
		plotter.init();
		plotter.dFiles(extractor.getData("Zeichnung.svg"));
		plotter.close();

	}

}
/*
 * 12 Zähne -> 36 Zähne 40mm Umfang 12 Zähne -> 36 Zähne
 * 
 * 1357,17mm
 */
//3*2,5```#