import lejos.hardware.motor.EV3LargeRegulatedMotor;
import lejos.hardware.port.MotorPort;

public class Printhead
{

	private boolean penUp;
	private double[] coords;
	EV3LargeRegulatedMotor Motor = new EV3LargeRegulatedMotor(MotorPort.B);

	public Printhead()
	{
		setPenUp(true);
		setCoords(new double[] { 0, 0 });
		Motor.setSpeed(20);
	}

	/**
	 * @return the penUp
	 */
	public boolean getPenUp()
	{
		return penUp;
	}

	/**
	 * @param penUp the penUp to set
	 */
	public void setPenUp(boolean penUp)
	{
		this.penUp = penUp;
	}

	/**
	 * @return the coords
	 */
	public double[] getCoords()
	{
		return coords;
	}

	/**
	 * @param coords the coords to set
	 */
	public void setCoords(double coords[])
	{
		this.coords = coords;
	}

	public void updateCoords(double x, double y)
	{
		this.coords[0] += x;
		this.coords[1] += y;
	}

	public void togglePen()
	{
		if (penUp)
		{
			// TODO Stift Runter Code
			Motor.rotate(-50);
			penUp = false;
		} else
		{
			// TODO Stift Hoch Code
			Motor.rotate(50);
			penUp = true;
		}
	}

}