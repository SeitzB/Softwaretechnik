import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
/*
Die Klasse SVGPathExtractor soll die Pfaddaten der SVG extrahieren
und diese anschließend in absolute Koordinaten unwandeln. 
*/
public class SVGPathExtractor
{
	public SVGPathExtractor()
	{

	}

	static public List<List<Coordinate>> getData(String path)
	{
		try
		{
			File svgFile = new File(path);

			List<List<Coordinate>> paths = new ArrayList();

			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document doc = builder.parse(svgFile);

			NodeList pathElements = doc.getElementsByTagName("path");
			for (int i = 0; i < pathElements.getLength(); i++)
			{
				Element pathElement = (Element) pathElements.item(i);
				String pathData = pathElement.getAttribute("d");					//die Zeilen mit Pfaddaten wird immer mit d eingeleitet, die Klasse Element scannt nach diesen Zeilen
				pathData = pathData + 'z';											//da nicht jede Zeile mit 'z' endet wird dies an den String angehangen
				paths.add(pathHelper(pathData));									//die Koordinaten des Pfades werden an die Pfad Liste angehangen
				System.out.println("Path " + (i + 1) + ": " + pathData);			
			}
			return paths;
		} catch (Exception e)
		{
			e.printStackTrace();
			return null;
		}

	}

	static List<Coordinate> pathHelper(String data)
	{
	/*	
	*	Die Methode pathHelper dient der weiteren Verarbeitung der Daten. Ihr wird ein String
 	* 	mit Pfaddaten übergeben. Die Methode soll dann die verschiedenen Modi erkennen und 
 	* 	absolute Koordinaten für den gesamten Pfad übergeben
	*/

		int arrPos = 0;
		List<Coordinate> Coordinates = new ArrayList();

		char mode = 'm';
		boolean modY = false;

		String number = "";

		int pos = 0;

		while (data.length() - 1 > pos)
		{
			switch (data.charAt(pos))
			{

				/*
				 * Die Switch-Case überprüft die verschiednen Modi und gibt die Datenverarbeitung
				 * dann an die jeweilige Methode für den entsprechenden Modus weiter. Durch die 
				 * Switch-Case ergibt sich ein Toggle, der jeweilige Modus bleibt so lange aktiv,
				 * bis ein neuer angegeben wird. 
				 */
			case 'm':
			{
				mode = 'm';
				pathReturn output = pathInit(pos, data);
				pos = output.getPos();
				Coordinates.add(output.getCoordinate());
				mode = 'l';
				break;
			}

			case 'M':
			{
				mode = 'M';
				pathReturn output = pathInit(pos, data);
				pos = output.getPos();
				Coordinates.add(output.getCoordinate());
				mode = 'L';
				break;
			}

			case 'h':
				mode = 'h';
				pos++;
				break;

			case 'H':
				mode = 'H';
				pos++;
				break;

			case 'v':
				mode = 'v';
				pos++;
				break;

			case 'V':
				mode = 'V';
				pos++;
				break;

			case 'l':
				mode = 'l';
				pos++;
				break;

			case 'L':
				mode = 'L';
				pos++;
				break;

			case 'z':
				mode = 'z';
				pos++;
				break;

			case 'Z':
				mode = 'Z';
				pos++;
				break;

			case ' ':			//Stößt die Switch-Case auf ein Leerzeichen überspringt sie dies einfach
				pos++;			
				modY = false;
				break;

			default:
			/*
			 * Der Default wird immer dann aufgerufen, wenn sich an der jeweiligen Stelle kein Modusoperator
			 * oder Leerzeichen befinden. In diese Situation wird eine Koordinate angegeben. Die folgende
			 * else-if Kontrollstruktur ruft die jeweiligen Methoden auf. Je nach Modus werden die Koordinaten
			 * absolut, oder relativ angegeben, es kann sich um eine vertikale, horizontale, oder diagonale 
			 * Linie handeln. Die jeweiligen Methoden geben ein Objekt der Klasse pathReturn zurück, dass
			 * die neue Position im String und die Koordinate übergibt. 
			 */
				if (mode == 'h')			//horizontale Linie relativ zur letzen Koordinate
				{
					pathReturn output = pathHorizontelRelative(pos, data, Coordinates.get(Coordinates.size() - 1));
					pos = output.getPos();
					Coordinates.add(output.getCoordinate());
				} else if (mode == 'H')		//horizontale Linie absolut 	
				{
					pathReturn output = pathHorizontelAbsolute(pos, data, Coordinates.get(Coordinates.size() - 1));
					pos = output.getPos();
					Coordinates.add(output.getCoordinate());
				} else if (mode == 'v')		//vertikale Linie relativ zur letzen Koordinate
				{
					pathReturn output = pathVerticalRelative(pos, data, Coordinates.get(Coordinates.size() - 1));
					pos = output.getPos();
					Coordinates.add(output.getCoordinate());
				} else if (mode == 'V')		//vertikale Linie absolut
				{
					pathReturn output = pathVerticalAbsolute(pos, data, Coordinates.get(Coordinates.size() - 1));
					pos = output.getPos();
					Coordinates.add(output.getCoordinate());
				} else if (mode == 'l')		//diagonale Linie realtiv zur letzen Koordinate
				{
					pathReturn output = pathRelative(pos, data, Coordinates.get(Coordinates.size() - 1));
					pos = output.getPos();
					Coordinates.add(output.getCoordinate());
				} else if (mode == 'L')		//diagonale Linie absolut
				{
					pathReturn output = pathAbsolute(pos, data);
					pos = output.getPos();
					Coordinates.add(output.getCoordinate());
				}
				pos++;
			}

		}

		return Coordinates;

	}

	static pathReturn pathInit(int pos, String data)
	{
		pos = pos + 2;
		String x = "";
		String y = "";

		while (data.charAt(pos) != ',')
		{
			x = x + data.charAt(pos);
			pos++;
		}

		pos++;

		while (data.charAt(pos) != ' ' && data.charAt(pos) != 'z')
		{
			y = y + data.charAt(pos);
			pos++;
		}

		return new pathReturn(convertStringsToCoordinate(x, y), pos);
	}

	static pathReturn pathHorizontelRelative(int pos, String data, Coordinate previous)
	{
		String tempX = "";

		while (data.charAt(pos) != ' ' && data.charAt(pos) != 'z')
		{
			tempX = tempX + data.charAt(pos);
			pos++;
		}

		float finishedX = Float.parseFloat(tempX) + previous.giveX();

		Coordinate finishedCoordinate = new Coordinate(finishedX, previous.giveY());

		return new pathReturn(finishedCoordinate, pos);

	}

	static pathReturn pathVerticalRelative(int pos, String data, Coordinate previous)
	{
		String tempY = "";

		while (data.charAt(pos) != ' ' && data.charAt(pos) != 'z')
		{
			tempY = tempY + data.charAt(pos);
			pos++;
		}

		float finishedY = Float.parseFloat(tempY) + previous.giveY();

		Coordinate finishedCoordinate = new Coordinate(previous.giveX(), finishedY);

		return new pathReturn(finishedCoordinate, pos);

	}

	static pathReturn pathHorizontelAbsolute(int pos, String data, Coordinate previous)
	{
		String tempX = "";

		while (data.charAt(pos) != ' ' && data.charAt(pos) != 'z')
		{
			tempX = tempX + data.charAt(pos);
			pos++;
		}

		Coordinate finishedCoordinate = new Coordinate(Float.parseFloat(tempX), previous.giveY());

		return new pathReturn(finishedCoordinate, pos);

	}

	static pathReturn pathVerticalAbsolute(int pos, String data, Coordinate previous)
	{
		String tempY = "";

		while (data.charAt(pos) != ' ' && data.charAt(pos) != 'z')
		{
			tempY = tempY + data.charAt(pos);
			pos++;
		}

		Coordinate finishedCoordinate = new Coordinate(previous.giveX(), Float.parseFloat(tempY));

		return new pathReturn(finishedCoordinate, pos);

	}

	static pathReturn pathRelative(int pos, String data, Coordinate previous)
	{
		String tempX = "";
		String tempY = "";

		while (data.charAt(pos) != ',')
		{
			tempX = tempX + data.charAt(pos);
			pos++;
		}

		pos++;

		while (data.charAt(pos) != ' ' && data.charAt(pos) != 'z')
		{
			tempY = tempY + data.charAt(pos);
			pos++;
		}

		float finishedX = Float.parseFloat(tempX) + previous.giveX();
		float finishedY = Float.parseFloat(tempY) + previous.giveY();

		Coordinate finishedCoordinate = new Coordinate(finishedX, finishedY);

		return new pathReturn(finishedCoordinate, pos);

	}

	static pathReturn pathAbsolute(int pos, String data)
	{
		String tempX = "";
		String tempY = "";

		while (data.charAt(pos) != ',')
		{
			tempX = tempX + data.charAt(pos);
			pos++;
		}

		pos++;

		while (data.charAt(pos) != ' ' && data.charAt(pos) != 'z')
		{
			tempY = tempY + data.charAt(pos);
			pos++;
		}

		Coordinate finishedCoordinate = new Coordinate(Float.parseFloat(tempX), Float.parseFloat(tempY));

		return new pathReturn(finishedCoordinate, pos);

	}

	static Coordinate convertStringsToCoordinate(String x, String y)		//Konvertiert den extrahierten Koordinatenstring in eine Koordinate
	{
		return new Coordinate(Float.parseFloat(x), Float.parseFloat(y));
	}
}
