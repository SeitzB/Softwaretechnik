public class main
{

	public static void main(String[] args)
	{
		Plotter plotter = new Plotter(); 							//Plotter Objekt wird erstellt
		SVGPathExtractor extractor = new SVGPathExtractor();		//SVGPathExtractor Objekt wird erstellt
		plotter.init();												//Plotter wird initialisiert
		plotter.dFiles(extractor.getData("Zeichnung.svg"));			//SVG Daten werden aus "Zeichnung.svg" extrahiert
		plotter.close();					

	}

}
/*
 * 12 Zähne -> 36 Zähne 40mm Umfang 12 Zähne -> 36 Zähne
 * 
 * 1357,17mm
 */
//3*2,5```#